package com.example.myapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import android.util.Log;


public class WeightEntryFragment extends Fragment {

    private Button btnAddEntry;
    private MyDbHelper dbHelper;
    private long userId;
    public void setUserId(long userId) {
        this.userId = userId;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.weight_entry_screen, container, false);

        btnAddEntry = view.findViewById(R.id.btnAddEntry);
        dbHelper = new MyDbHelper(getActivity(), userId);

        btnAddEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editTextDate = view.findViewById(R.id.editTextDate);
                EditText editTextWeight = view.findViewById(R.id.editTextWeight);
                String date = editTextDate.getText().toString();
                String weightString = editTextWeight.getText().toString();

                // Check if date and weight are not empty
                if (date.isEmpty() || weightString.isEmpty()) {
                    Toast.makeText(getActivity(), "Please enter date and weight", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Parse weight to double
                double weight = Double.parseDouble(weightString);


                // Insert entry into the database
                long newRowId = dbHelper.insertWeightEntry(date, weight);

                // Log the result
                if (newRowId != -1) {
                    Log.d("WeightEntry", "Weight entry added successfully. New row ID: " + newRowId);
                    Toast.makeText(getActivity(), "Weight entry added successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Log.d("WeightEntry", "Failed to add weight entry.");
                    Toast.makeText(getActivity(), "Failed to add weight entry", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return view;
    }
}