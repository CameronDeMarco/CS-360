package com.example.myapp;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import java.util.ArrayList;

public class WeightDataFragment extends Fragment {

    private MyDbHelper dbHelper;
    private ArrayAdapter<String> mAdapter;
    private ListView listViewData;
    private Cursor cursor;
    private long userId;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.weight_data_screen, container, false);

        // Initialize database helper
        dbHelper = new MyDbHelper(getActivity());

        Button addButton = view.findViewById(R.id.btnAddData);
        listViewData = view.findViewById(R.id.ListViewData);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the weight entry screen
                Navigation.findNavController(v).navigate(R.id.action_weightDataFragment_to_weightEntryFragment);
            }
        });

        mAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, new ArrayList<String>());
        listViewData.setAdapter(mAdapter);
        // Load data from the database
        long userId = getUserId();
        Log.d("UserId", "User ID: " + userId); // Log the user ID
        // Retrieve the user ID of the currently user
        userId = getUserId();

        loadData();

        return view;
    }

    private void loadData() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Columns being retrieved
        String[] projection = {
                WeightEntriesContract.FeedEntry._ID,
                WeightEntriesContract.FeedEntry.COLUMN_NAME_DATE,
                WeightEntriesContract.FeedEntry.COLUMN_NAME_WEIGHT
        };

        String selection = WeightEntriesContract.FeedEntry.COLUMN_NAME_USER_ID + " = ?";
        String[] selectionArgs = {String.valueOf(userId)};

        // Query the database
        cursor = db.query(
                WeightEntriesContract.FeedEntry.TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        // Clear previous data
        mAdapter.clear();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                // Get data from cursor
                String date = cursor.getString(cursor.getColumnIndexOrThrow(WeightEntriesContract.FeedEntry.COLUMN_NAME_DATE));
                float weight = cursor.getFloat(cursor.getColumnIndexOrThrow(WeightEntriesContract.FeedEntry.COLUMN_NAME_WEIGHT));
                // Format data
                String entry = "Date: " + date + ", Weight: " + weight;
                mAdapter.add(entry);
            } while (cursor.moveToNext());
        }
    }

    private long getUserId() {

        return userId;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (cursor != null) {
            cursor.close();
        }
        dbHelper.close();
    }
}
