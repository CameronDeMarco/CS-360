package com.example.myapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class UserLoginFragment extends Fragment {
    private static final String TAG = "UserLoginFragment";

    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button btnLogin;
    private Button btnCreateAccount;
    private Button btnLogout;
    private TextView tvWelcomeMessage;
    private MyDbHelper dbHelper;
    private boolean isLoggedIn = false;
    private String loggedInUsername;
    private long loggedInUserId = -1; // Indicate no user logged in


    public UserLoginFragment() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Initialize database helper
        dbHelper = new MyDbHelper(getActivity());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.user_login_screen, container, false);

        editTextUsername = view.findViewById(R.id.editTextUsername);
        editTextPassword = view.findViewById(R.id.editTextPassword);
        btnLogin = view.findViewById(R.id.btnLogin);
        btnCreateAccount = view.findViewById(R.id.btnCreateAccount);
        btnLogout = view.findViewById(R.id.btnLogout);
        tvWelcomeMessage = view.findViewById(R.id.TvWelcomeMessage);

        updateUI();

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isLoggedIn) {
                    loginUser();
                }
            }
        });

        btnCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isLoggedIn) {
                    createAccount();
                }
            }
        });

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isLoggedIn) {
                    logoutUser();
                }
            }
        });

        return view;
    }

    private void updateUI() {
        if (isLoggedIn) {
            // Hides login
            editTextUsername.setVisibility(View.GONE);
            editTextPassword.setVisibility(View.GONE);
            btnLogin.setVisibility(View.GONE);
            btnCreateAccount.setVisibility(View.GONE);

            // Welcome message
            tvWelcomeMessage.setVisibility(View.VISIBLE);
            tvWelcomeMessage.setText("Welcome, " + loggedInUsername);
            btnLogout.setVisibility(View.VISIBLE);
        } else {
            // Show login
            editTextUsername.setVisibility(View.VISIBLE);
            editTextPassword.setVisibility(View.VISIBLE);
            btnLogin.setVisibility(View.VISIBLE);
            btnCreateAccount.setVisibility(View.VISIBLE);

            // Hide welcome message
            tvWelcomeMessage.setVisibility(View.GONE);
            btnLogout.setVisibility(View.GONE);
        }
    }
    private void loginUser() {
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String[] projection = {
                UserContract.UserEntry._ID,
                UserContract.UserEntry.COLUMN_USERNAME,
                UserContract.UserEntry.COLUMN_PASSWORD
        };

        String selection = UserContract.UserEntry.COLUMN_USERNAME + " = ? AND " +
                UserContract.UserEntry.COLUMN_PASSWORD + " = ?";

        String[] selectionArgs = {username, password};

        // Query the database
        Cursor cursor = db.query(
                UserContract.UserEntry.TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        // Check if the cursor has any users
        if (cursor.moveToFirst()) {
            // Check if the _ID column exists in the cursor
            int idColumnIndex = cursor.getColumnIndex(UserContract.UserEntry._ID);
            if (idColumnIndex != -1) {
                // Retrieve the user ID from the cursor
                loggedInUserId = cursor.getLong(idColumnIndex);
                isLoggedIn = true;
                loggedInUsername = username;
                Toast.makeText(getActivity(), "Login successful", Toast.LENGTH_SHORT).show();
                updateUI();
            } else {
                // Handle case where _ID column is missing
                Log.e(TAG, "Column _ID not found in cursor");
            }
        } else {
            Toast.makeText(getActivity(), "Invalid username or password", Toast.LENGTH_SHORT).show();
        }

        // Close cursor and database
        cursor.close();
        db.close();
    }
// Creating an account
    private void createAccount() {
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Create a new map of value
        ContentValues values = new ContentValues();
        values.put(UserContract.UserEntry.COLUMN_USERNAME, username);
        values.put(UserContract.UserEntry.COLUMN_PASSWORD, password);

        // Insert new row
        long newRowId = db.insert(UserContract.UserEntry.TABLE_NAME, null, values);

        if (newRowId != -1) {
            isLoggedIn = true;
            loggedInUsername = username;
            Toast.makeText(getActivity(), "Account created successfully", Toast.LENGTH_SHORT).show();
            updateUI();
        } else {
            Toast.makeText(getActivity(), "Failed to create account", Toast.LENGTH_SHORT).show();
        }

        // Close database
        db.close();
    }

    private void logoutUser() {
        isLoggedIn = false;
        updateUI();
        Toast.makeText(getActivity(), "Logged out successfully", Toast.LENGTH_SHORT).show();
    }
}
