package com.example.myapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class MyDbHelper extends SQLiteOpenHelper {
    // Database and table information
    public static final int DATABASE_VERSION = 3;
    public static final String DATABASE_NAME = "FeedReader.db";
    private static final String COLUMN_NAME_USER_ID = "user_id";
    private long userId;
// Creating weight entries table
    private static final String SQL_CREATE_WEIGHT_ENTRIES =
            "CREATE TABLE " + WeightEntriesContract.FeedEntry.TABLE_NAME + " (" +
                    WeightEntriesContract.FeedEntry._ID + " INTEGER PRIMARY KEY," +
                    WeightEntriesContract.FeedEntry.COLUMN_NAME_DATE + " TEXT," +
                    WeightEntriesContract.FeedEntry.COLUMN_NAME_WEIGHT + " REAL," +
                    WeightEntriesContract.FeedEntry.COLUMN_NAME_USER_ID + " INTEGER)";
    // Creating User table
    private static final String SQL_CREATE_USER_ENTRIES =
            "CREATE TABLE " + UserContract.UserEntry.TABLE_NAME + " (" +
                    UserContract.UserEntry._ID + " INTEGER PRIMARY KEY," +
                    UserContract.UserEntry.COLUMN_USERNAME + " TEXT," +
                    UserContract.UserEntry.COLUMN_PASSWORD + " TEXT)";
    public MyDbHelper(Context context, long userId) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.userId = userId; // Initialize user ID
    }
    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + WeightEntriesContract.FeedEntry.TABLE_NAME;

    public MyDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_WEIGHT_ENTRIES);
        if (!tableExists(db, UserContract.UserEntry.TABLE_NAME)) {
            db.execSQL(SQL_CREATE_USER_ENTRIES);
        }
    }

    private boolean tableExists(SQLiteDatabase db, String tableName) {
        Cursor cursor = db.rawQuery(
                "SELECT * FROM sqlite_master WHERE type='table' AND name=?",
                new String[]{tableName}
        );
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }
    private long getUserId() {
        Log.d("UserId", "Attempting to retrieve user ID...");

        Log.d("UserId", "User ID retrieved: " + userId);

        return userId;
    }

    // Function to insert weight entries in the table
public long insertWeightEntry(String date, double weight) {
    SQLiteDatabase db = this.getWritableDatabase();
    ContentValues values = new ContentValues();
    values.put(COLUMN_NAME_USER_ID, getUserId());
    values.put(WeightEntriesContract.FeedEntry.COLUMN_NAME_DATE, date);
    values.put(WeightEntriesContract.FeedEntry.COLUMN_NAME_WEIGHT, weight);
    return db.insert(WeightEntriesContract.FeedEntry.TABLE_NAME, null, values);
}
}
