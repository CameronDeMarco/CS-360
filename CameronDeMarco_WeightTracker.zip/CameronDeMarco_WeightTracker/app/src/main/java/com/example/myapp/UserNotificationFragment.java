package com.example.myapp;

import android.Manifest;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

public class UserNotificationFragment extends Fragment {

    private static final int PERMISSION_REQUEST_SEND_NOTIFICATION = 1;

    public UserNotificationFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.user_notification_screen, container, false);

        // Button to allow
        Button allowButton = rootView.findViewById(R.id.btnAllow);
        allowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestSMSPermission();
            }
        });

        // Button to deny
        Button denyButton = rootView.findViewById(R.id.btnDeny);
        denyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(requireContext(), "SMS permission denied, SMS feature disabled", Toast.LENGTH_SHORT).show();
            }
        });

        return rootView;
    }

    private void requestSMSPermission() {
        // Request user permission
        ActivityCompat.requestPermissions(requireActivity(),
                new String[]{Manifest.permission.SEND_SMS},
                PERMISSION_REQUEST_SEND_NOTIFICATION);
    }
}
