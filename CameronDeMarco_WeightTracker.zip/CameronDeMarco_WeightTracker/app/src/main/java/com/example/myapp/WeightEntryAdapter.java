package com.example.myapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.database.Cursor;
import android.widget.CursorAdapter;

public class WeightEntryAdapter extends CursorAdapter {

    public WeightEntryAdapter(Context context, Cursor cursor) {
        super(context, cursor, 0);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.grid_item_layout, parent, false);
    }
// Bind data in view
    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        TextView dateTextView = view.findViewById(R.id.textViewDate);
        TextView weightTextView = view.findViewById(R.id.textViewWeight);

        String date = cursor.getString(cursor.getColumnIndexOrThrow(WeightEntriesContract.FeedEntry.COLUMN_NAME_DATE));
        double weight = cursor.getDouble(cursor.getColumnIndexOrThrow(WeightEntriesContract.FeedEntry.COLUMN_NAME_WEIGHT));

        dateTextView.setText(date);
        weightTextView.setText(String.valueOf(weight));
    }
}
